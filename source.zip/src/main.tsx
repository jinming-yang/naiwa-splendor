import React from 'react';import {createRoot} from 'react-dom/client';import Table from './table';import './globals.css';createRoot(document.getElementById('root')!).render(<Table/>);
