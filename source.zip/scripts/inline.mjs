import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');const docs=path.join(root,'docs');
let html=fs.readFileSync(path.join(docs,'index.html'),'utf8');
const script=html.match(/<script\b[^>]*src="([^"]+)"[^>]*><\/script>/);const style=html.match(/<link\b[^>]*href="([^"]+\.css)"[^>]*>/);
if(!script||!style)throw Error('Build output missing JS or CSS');
let js=fs.readFileSync(path.resolve(docs,script[1]),'utf8'),css=fs.readFileSync(path.resolve(docs,style[1]),'utf8');
const artRoot=path.join(root,'public/art');
function embed(dir){for(const d of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,d.name);if(d.isDirectory()){embed(p);continue}const url='/art/'+path.relative(artRoot,p).replaceAll('\\','/');if(!js.includes(url))continue;const ext=path.extname(p).slice(1),mime=ext==='jpg'?'image/jpeg':'image/'+ext;const uri='data:'+mime+';base64,'+fs.readFileSync(p).toString('base64');js=js.replaceAll(url,uri)}}embed(artRoot);
if(/(?:"|')\/art\//.test(js))throw Error('Unbundled artwork URLs remain');
html=html.replace(script[0],()=>'<script type="module">'+js.replaceAll('</script','<\\/script')+'</script>');html=html.replace(style[0],()=>'<style>'+css+'</style>');fs.writeFileSync(path.join(docs,'index.html'),html);fs.writeFileSync(path.join(docs,'.nojekyll'),'');
console.log('Self-contained GitHub Pages index:',Buffer.byteLength(html),'bytes');

